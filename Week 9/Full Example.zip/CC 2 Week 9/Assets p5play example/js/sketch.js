
var idlePaths = [];

function preload() {
   idlePaths = loadStrings("./images/idle/idle.txt");
}

function setup() {
  createCanvas(800,600);
  myAnimation = new animationImage(idlePaths, 0, 0, 150, 150);
 

}

// display all the frames using the draw function as a loop
function draw() 
{

    background(120);
    myAnimation.updatePosition('idle');
    myAnimation.setCurrentFrameCount(frameCount);
    myAnimation.drawAnimation();
}