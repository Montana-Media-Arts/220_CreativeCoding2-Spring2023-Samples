class animationImage
{

    constructor(fileNames, x, y, w, h)
    {
        this.fileNames = fileNames;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.imageObjects = [];
        this.loadAnimation();
        this.i = 0;
        this.currentFrameCount = 0;
        this.direction  = "";
        this.currentAnimation;
        
    }

    getX()
    {
        return this.x;
    }

    setX(x)
    {
        this.x = x;
    }

    setCurrentFrameCount(currentFrameCount)
    {

        this.currentFrameCount = currentFrameCount;
    }

    loadAnimation()
    {
        this.currentAnimation = loadAnimation(this.fileNames[0], this.fileNames[this.fileNames.length-1]);
        //for(var i = 0; i < this.fileNames.length; i++)
        //{
         //   this.imageObjects[i] = loadImage(this.fileNames[i]);
        //}
         
    }


    drawAnimation()
    {  
        //this.incrementIndex();
       // if(this.direction == "reverse")
       // {
       //     translate(this.w,0);
       //     scale(-1.0,1.0);
       //     image(this.imageObjects[this.i], -this.x, this.y, this.w, this.h);
       // }
       // else
       // {
            //image(this.imageObjects[this.i], this.x, this.y, this.w, this.h);
        //}
        this.currentAnimation.frameDelay = 5; 
        animation(this.currentAnimation, 300, 250);
           
        
    }

    incrementIndex() {
       
        if(this.currentFrameCount % 5 == 0)
        {
            this.i++;
        }
       
        if (this.i >= this.fileNames.length) {
            this.i = 0;
        }
    }

    updatePosition(direction)
    {
        this.direction = direction;
        if(direction == "forward")
        {
            this.x += 1;
        }
        else if(direction == "reverse")
        {   
            this.x -= 1;
            
        }
    }

    isRectanglesColliding(rectangle2){

        return collideRectRect(this.x, this.y, 
         this.w, this.h,rectangle2.getX(), rectangle2.getY(),
          rectangle2.getW(), rectangle2.getH());
       /* var topEdge1 = this.y + this.h;
        var rightEdge1 = this.x + this.w; 
        var leftEdge1 = this.x;
        var bottomEdge1 = this.y;
        var topEdge2 = rec2.getY() + rec2.getH();
        var rightEdge2 = rec2.getX() + rec2.getW(); 
        var leftEdge2 = rec2.getX();
        var bottomEdge2 = rec2.getY();   
        
        if( leftEdge1 < rightEdge2 && rightEdge1 > leftEdge2 && bottomEdge1 < topEdge2 && topEdge1 > bottomEdge2){
            return true; 
       }
       return false;
       */
    }
    
}